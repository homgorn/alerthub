# ✅ БЫСТРЫЙ ЧЕКЛИСТ: GitHub за 30 минут

## ⏱️ Шаг за шагом (для нетерпеливых)

### ✅ 5 минут: Подготовка

```bash
# 1. Проверь Git
git --version

# Если ошибка - скачай https://git-scm.com/download/win (или Mac/Linux)
```

### ✅ 5 минут: Создай папку

**На Windows:**
```bash
cd Desktop
mkdir alerts-hub
cd alerts-hub
```

**На Mac/Linux:**
```bash
cd ~/Desktop
mkdir alerts-hub
cd alerts-hub
```

### ✅ 5 минут: Скопируй файлы

1. Открой `/outputs/` 
2. Выбери ВСЕ файлы (Ctrl+A)
3. Скопируй (Ctrl+C)
4. Открой папку `alerts-hub` 
5. Вставь (Ctrl+V)

**Проверка:**
```bash
ls -la  # На Mac/Linux
dir     # На Windows

# Должны видеть файлы:
# README.md, ROADMAP.md, gmail_api.py, ...
```

### ✅ 10 минут: GitHub

**1. Создай аккаунт:** https://github.com/signup

**2. Создай репо:** https://github.com/new
   - Name: `alerts-hub`
   - Public или Private (неважно)
   - SKIP "Initialize with README"
   - Click **Create repository**

**3. Скопируй URL репо:**
   ```
   https://github.com/YOUR-USERNAME/alerts-hub.git
   ```

### ✅ 5 минут: Git команды

Открой Терминал в папке `alerts-hub`:

```bash
# 1. Инициализация
git init

# 2. Добавь файлы
git add -A

# 3. Первый коммит
git commit -m "AlertsHub: Complete news + trend discovery platform"

# 4. Подключи GitHub (ЗАМЕНИ ТУ-USERNAME!)
git remote add origin https://github.com/YOUR-USERNAME/alerts-hub.git

# 5. Загрузи
git branch -M main
git push -u origin main
```

### ✅ Готово!

Проверь: https://github.com/YOUR-USERNAME/alerts-hub

---

## 🎯 Если что-то не работает

| Ошибка | Решение |
|--------|---------|
| `git: command not found` | Скачай Git с https://git-scm.com/ |
| `fatal: not a git repository` | Проверь что ты в папке `alerts-hub` |
| `Permission denied (publickey)` | Добавь SSH ключ в GitHub settings |
| `Repository already exists` | Удали `.git` папку: `rm -rf .git` |
| `fatal: 'origin' already exists` | Удали старый remote: `git remote rm origin` |

---

## 📺 Быстрый тест

После загрузки, проверь что видишь на GitHub:

```
✅ alerts-hub репо существует
✅ 17 файлов загружены
✅ README.md красиво отформатирован
✅ Может читать 1 коммит "AlertsHub: Complete..."
```

Если ВСЁ ✅ - ПОЗДРАВЛЯЮ! 🎉

---

## 🚀 Что дальше?

После загрузки на GitHub:

1. **Прочитай:** README.md + GITHUB_QUICKSTART.md
2. **Создай** первую ветку: `git checkout -b feature/phase1-setup`
3. **Установи** зависимости: `pip install -r requirements.txt`
4. **Запусти** первый парсер: `python gmail_api.py`
5. **Делай** Phase 1!

---

## 💬 IMPORTANT NOTES

```
⚠️  Если у тебя есть credentials.json или .env
    - НЕ коммитить их на GitHub!
    - Они уже в .gitignore
    - Но проверь что не случайно не загрузилось

🔒 Git Best Practice:
    - Коммитить часто (каждый час)
    - Писать понятные сообщения
    - Использовать ветки для разработки
    - Пушить каждый день

📖 Учись по ходу:
    - Гугли ошибки которые видишь
    - StackOverflow спасает 99% проблем
    - Git документация: https://git-scm.com/doc
```

---

## 📞 Если СОВСЕМ не получается

**Вариант 1: GitHub Desktop (Графический интерфейс)**

1. Скачай https://desktop.github.com/
2. Открой папку `alerts-hub` 
3. Нажми "Publish repository"
4. ВСЁ! 🎉

**Вариант 2: VS Code встроенный Git**

1. Открой VS Code
2. File → Open Folder → `alerts-hub`
3. Слева нажми иконку Git (3 кружочка)
4. Нажми "Initialize Repository"
5. Напиши сообщение коммита
6. Нажми Publish Branch

**Обе программы делают ТО ЖЕ что команды выше, но ГРАФИЧЕСКИ!**

---

**ВСЁ ГОТОВО!** 🚀

Если потребуется помощь - я здесь!
