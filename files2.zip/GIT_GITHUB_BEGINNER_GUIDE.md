# 🚀 Как загрузить AlertsHub на GitHub (Для начинающих)

## Шаг 1: Подготовка (5 минут)

### 1.1 Установи Git (если не установлен)

**На Windows:**
1. Открой https://git-scm.com/download/win
2. Скачай и установи (всё по дефолту)
3. Перезагрузи компьютер

**На Mac:**
```bash
# Открой Terminal и скопируй:
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install git
```

**На Linux:**
```bash
sudo apt update
sudo apt install git
```

### 1.2 Проверь что Git установлен

Открой **Терминал** (или **PowerShell** на Windows) и напиши:

```bash
git --version
```

Если видишь версию (напр. `git version 2.45.0`) - отлично!

---

## Шаг 2: Создай папку проекта

### Вариант A: Через файловый менеджер (САМЫЙ ПРОСТОЙ)

```
1. Открой мой компьютер
2. Перейди в папку C:\Users\TvoeImya\Desktop (или Desktop на Mac)
3. Создай новую папку: ПКМ → New Folder → alerts-hub
4. Открой эту папку
5. Положи сюда ВСЕ 17 файлов из outputs/
```

### Вариант B: Через Терминал

```bash
# На Windows (PowerShell):
cd Desktop
mkdir alerts-hub
cd alerts-hub

# На Mac/Linux:
cd ~/Desktop
mkdir alerts-hub
cd alerts-hub
```

**Вывод на экране должен быть примерно так:**
```
C:\Users\YourName\Desktop\alerts-hub>
```

или на Mac:
```
~/Desktop/alerts-hub $
```

---

## Шаг 3: Скопируй файлы в папку

### Где взять файлы?

1. Открой `/outputs/` (где я создал 17 файлов)
2. Выбери ВСЕ файлы (Ctrl+A)
3. Скопируй (Ctrl+C)
4. Перейди в папку `alerts-hub` что ты создал
5. Вставь (Ctrl+V)

**Результат:**
```
alerts-hub/
├── README.md
├── ROADMAP.md
├── gmail_api.py
├── exploding_topics_parser.py
├── requirements.txt
├── ... (и другие 11 файлов)
```

---

## Шаг 4: Создай GitHub аккаунт (если нет)

### 4.1 Зарегистрируйся

1. Открой https://github.com/
2. Нажми **Sign up** (зелёная кнопка)
3. Введи:
   - Email (например: tvoe.imya@gmail.com)
   - Пароль (сложный!)
   - Username (например: ivan-developer)
4. Подтверди через письмо

### 4.2 Установи SSH ключ (опционально, но рекомендую)

Это чтобы не вводить пароль каждый раз.

На Windows (PowerShell) или Mac/Linux (Terminal):

```bash
# 1. Создай SSH ключ
ssh-keygen -t ed25519 -C "tvoe.imya@gmail.com"

# 2. Когда спросит, просто нажми ENTER 3 раза
# (не вводи пароль)

# 3. Скопируй публичный ключ
# На Windows:
type $env:USERPROFILE\.ssh\id_ed25519.pub

# На Mac/Linux:
cat ~/.ssh/id_ed25519.pub
```

Скопируй весь текст что вывелся.

Потом:
1. Открой https://github.com/settings/keys
2. Нажми **New SSH key**
3. Вставь скопированный текст
4. Нажми **Add SSH key**

---

## Шаг 5: Создай пустой репозиторий на GitHub

### 5.1 Создание

1. Открой https://github.com/new
2. Введи:
   - **Repository name:** `alerts-hub` (важно, точно так!)
   - **Description:** "AI-powered news aggregation + trend discovery platform"
   - **Public** или **Private** (тебе выбирать)
   - НЕ выбирай "Initialize with README" (у нас уже есть!)
3. Нажми **Create repository** (зелёная кнопка)

### 5.2 Что ты увидишь

Страница с инструкциями. **ЗАКРОЙ её!** Тебе эти команды не нужны - я дам свои.

---

## Шаг 6: GIT МАГИЯ (Самая важная часть)

### Открой Терминал в папке alerts-hub

**Вариант 1: Через файловый менеджер (САМЫЙ ПРОСТОЙ)**

1. Открой папку `alerts-hub`
2. ПКМ (правая кнопка мыши) в пустом месте
3. Выбери **Open in Terminal** или **Open PowerShell here**

**Результат:** Терминал откроется и уже будет в этой папке!

**Вариант 2: Вручную через Терминал**

```bash
# Windows:
cd C:\Users\TvoeImya\Desktop\alerts-hub

# Mac:
cd ~/Desktop/alerts-hub

# Linux:
cd ~/Desktop/alerts-hub
```

---

## Шаг 7: Выполни Git команды

### В Терминале скопируй эти команды ОДНУ ЗА ДРУГОЙ:

#### Команда 1: Инициализация

```bash
git init
```

**Что произойдёт:**
```
Initialized empty Git repository in C:\Users\TvoeImya\Desktop\alerts-hub\.git
```

#### Команда 2: Добавь все файлы

```bash
git add -A
```

**Не выведется ничего** - это нормально!

#### Команда 3: Первый коммит

```bash
git commit -m "Initial commit: AlertsHub - news aggregation + trend discovery platform"
```

**Вывод будет примерно так:**
```
[main (root-commit) abc1234] Initial commit: AlertsHub - news aggregation + trend discovery platform
 17 files changed, 5000 insertions(+)
 create mode 100644 README.md
 create mode 100644 gmail_api.py
 ...
```

#### Команда 4: Подключи свой GitHub репо

```bash
# ЗАМЕНИ YOUR-USERNAME на свой GitHub username!
git remote add origin https://github.com/YOUR-USERNAME/alerts-hub.git
```

**Пример (если твой username "ivan-developer"):**
```bash
git remote add origin https://github.com/ivan-developer/alerts-hub.git
```

**Проверка:**
```bash
git remote -v
```

Должно вывести:
```
origin  https://github.com/YOUR-USERNAME/alerts-hub.git (fetch)
origin  https://github.com/YOUR-USERNAME/alerts-hub.git (push)
```

#### Команда 5: Загрузи на GitHub

```bash
git branch -M main
git push -u origin main
```

**Первый раз спросит username и password:**
```
Username for 'https://github.com': [введи username]
Password for 'https://ivan-developer@github.com': [введи пароль]
```

**Или скопирует твой SSH ключ если ты его добавил.**

**Успех выглядит так:**
```
Enumerating objects: 17, done.
Counting objects: 100% (17/17), done.
Delta compression using up to 8 threads
Compressing objects: 100% (15/15), done.
Writing objects: 100% (17/17), 125.00 KiB | 500.00 KiB/s, done.
Total 17 (delta 0), reused 0 (delta 0)
To https://github.com/ivan-developer/alerts-hub.git
 * [new branch]      main -> main
Branch 'main' is set up to track remote branch 'main' from 'origin'.
```

---

## Шаг 8: Проверка

Открой https://github.com/YOUR-USERNAME/alerts-hub

Должны видеть:
- ✅ Все 17 файлов
- ✅ README.md красиво отформатирован
- ✅ Зелёную галочку "Initial commit"

---

## 🎉 ГОТОВО!

Теперь твой проект на GitHub!

---

## Если что-то пошло не так

### Ошибка: "fatal: not a git repository"

**Решение:**
```bash
# Проверь что ты в правильной папке
pwd  # На Mac/Linux
cd   # На Windows

# Должно быть что-то вроде:
# /Users/name/Desktop/alerts-hub
# или
# C:\Users\Name\Desktop\alerts-hub
```

### Ошибка: "git: command not found"

**Решение:**
- Git не установлен
- Переустанови из https://git-scm.com/

### Ошибка: "Repository already exists"

**Решение:**
```bash
# Удали старый репо
rm -rf .git

# Начни сначала с "git init"
git init
```

### Ошибка при git push: "Permission denied"

**Решение:**
- Проверь username в GitHub
- Проверь что репо создано
- Сгенерируй новый SSH ключ

---

## 📚 Полезные команды (для будущего)

```bash
# Проверить статус
git status

# Добавить изменения
git add -A

# Сделать коммит
git commit -m "Описание изменений"

# Загрузить на GitHub
git push

# Получить обновления
git pull

# Создать новую ветку
git checkout -b feature/название

# Переключиться на ветку
git checkout main
```

---

## 🎯 NEXT: После загрузки на GitHub

### Шаг 9: Создай первую ветку для разработки

```bash
git checkout -b develop
git push -u origin develop
```

### Шаг 10: Создай ветку для Phase 1

```bash
git checkout -b feature/phase1-gmail-api
# Делай работу...
git add -A
git commit -m "Phase 1: Implement Gmail API parser"
git push origin feature/phase1-gmail-api
```

### Шаг 11: Создай Pull Request на GitHub

1. Открой https://github.com/YOUR-USERNAME/alerts-hub
2. Нажми **Compare & pull request**
3. Добавь описание
4. Нажми **Create pull request**
5. Слей в main когда готово

---

## 💡 ПРАВИЛА GIT

```
✅ DO:
  - Коммитить часто (каждый час работы)
  - Писать понятные сообщения коммитов
  - Делать отдельные ветки для разных фич
  - Регулярно пушить на GitHub

❌ DON'T:
  - Не коммитить секреты (API keys, passwords)
  - Не забывать что-то в .gitignore
  - Не делать огромные коммиты (100+ файлов)
  - Не работать прямо в main (используй ветки!)

.gitignore правила:
  - credentials.json (скачан из Google)
  - token.pickle (генерируется автоматически)
  - .env (с твоими API ключами!)
  - __pycache__/ (питон кэш)
  - venv/ (виртуальное окружение)
```

---

## 🎬 ВИДЕО ГАЙДЫ (если нужны)

- Git для новичков: https://www.youtube.com/watch?v=SWYqp7iY_Tc
- GitHub Desktop (графический интерфейс): https://desktop.github.com/
- VS Code Git integration: встроено в VS Code

---

**УСПЕХИ В РАЗРАБОТКЕ!** 🚀

Как только загрузишь на GitHub - напиши, помогу с Phase 1!
