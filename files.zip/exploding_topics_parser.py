"""
Exploding Topics Trend Parser

Модуль для парсинга трендов с explodingtopics.com с метриками:
- Volume (monthly searches)
- Growth (% growth rate)
- Trend Score (наш собственный алгоритм)

Источник: https://github.com/PolSust/exploding-topics-scraper

Теория:
├─ Volume (1.6K) = 1600 человек в месяц ищут этот тренд
├─ Growth (+6800%) = интерес вырос в 69 раз
└─ Early Trend = High Growth + Low Volume = ракета 🚀
"""

import requests
from typing import List, Dict, Optional
from datetime import datetime
import logging
import json
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class TrendMetrics:
    """Метрики тренда"""
    volume: int  # Monthly searches
    growth: float  # Growth percentage (e.g., 6800 = +6800%)
    growth_direction: str  # "up", "down", "stable"
    
    def __post_init__(self):
        """Парсим growth direction из знака"""
        if self.growth > 0:
            self.growth_direction = "up"
        elif self.growth < 0:
            self.growth_direction = "down"
        else:
            self.growth_direction = "stable"


@dataclass
class Trend:
    """Тренд с метриками"""
    name: str
    category: str
    metrics: TrendMetrics
    description: Optional[str] = None
    url: Optional[str] = None
    fetched_at: str = None
    
    def __post_init__(self):
        if self.fetched_at is None:
            self.fetched_at = datetime.now().isoformat()


class TrendScorer:
    """
    Алгоритм оценки трендов.
    
    Принцип:
    - Early trends (High Growth + Low Volume) = BEST (самые ценные)
    - Emerging trends (Medium Growth + Medium Volume) = GOOD
    - Hyper trends (High Growth + High Volume) = HOT (очень популярные)
    - Mature trends (Low Growth + High Volume) = ESTABLISHED (стабильные)
    """
    
    # Пороги для классификации
    VOLUME_THRESHOLDS = {
        'low': 10_000,        # < 10K searches/month
        'medium': 50_000,     # 10K-50K
        'high': 250_000,      # 50K-250K
    }
    
    GROWTH_THRESHOLDS = {
        'low': 10,            # < 10% growth
        'medium': 100,        # 10%-100% growth
        'high': 1000,         # 100%-1000% growth
        'explosive': 5000,    # > 1000% growth (5x+)
    }
    
    # Scores для разных типов трендов
    TREND_SCORES = {
        'early_trend': {
            'score': 95,
            'label': '🚀 EARLY TREND',
            'description': 'High growth but still low volume. First-movers advantage!'
        },
        'rocket_trend': {
            'score': 90,
            'label': '🎯 ROCKET TREND',
            'description': 'Explosive growth. Gaining massive traction!'
        },
        'hyper_trend': {
            'score': 85,
            'label': '🔥 HYPER TREND',
            'description': 'High growth AND high volume. Mainstream adoption!'
        },
        'emerging_trend': {
            'score': 70,
            'label': '📈 EMERGING TREND',
            'description': 'Moderate growth and volume. Building momentum.'
        },
        'established_trend': {
            'score': 50,
            'label': '📊 ESTABLISHED',
            'description': 'Low growth but high volume. Stable, mature trend.'
        },
        'niche_trend': {
            'score': 60,
            'label': '🎨 NICHE',
            'description': 'Low volume but growing. Specialized market.'
        },
        'declining_trend': {
            'score': 20,
            'label': '📉 DECLINING',
            'description': 'Negative growth. Losing momentum.'
        },
        'stable_trend': {
            'score': 40,
            'label': '➡️ STABLE',
            'description': 'No growth, no decline. Flatlined.'
        }
    }
    
    @classmethod
    def classify_trend(cls, trend: Trend) -> Dict:
        """
        Классифицируй тренд по Volume + Growth.
        
        Returns:
            {
                'trend_type': 'early_trend',
                'score': 95,
                'label': '🚀 EARLY TREND',
                'ranking': 'Must Watch',
                'timeline': 'next 3-6 months'
            }
        """
        volume = trend.metrics.volume
        growth = trend.metrics.growth
        
        # Classify by volume
        if volume < cls.VOLUME_THRESHOLDS['low']:
            volume_class = 'low'
        elif volume < cls.VOLUME_THRESHOLDS['medium']:
            volume_class = 'medium'
        elif volume < cls.VOLUME_THRESHOLDS['high']:
            volume_class = 'high'
        else:
            volume_class = 'very_high'
        
        # Classify by growth
        if growth < 0:
            growth_class = 'declining'
        elif growth < cls.GROWTH_THRESHOLDS['low']:
            growth_class = 'stable'
        elif growth < cls.GROWTH_THRESHOLDS['medium']:
            growth_class = 'low_growth'
        elif growth < cls.GROWTH_THRESHOLDS['high']:
            growth_class = 'medium_growth'
        elif growth < cls.GROWTH_THRESHOLDS['explosive']:
            growth_class = 'high_growth'
        else:
            growth_class = 'explosive_growth'
        
        # Определи тип тренда
        trend_type = cls._get_trend_type(volume_class, growth_class)
        trend_info = cls.TREND_SCORES[trend_type]
        
        return {
            'trend_type': trend_type,
            'volume_class': volume_class,
            'growth_class': growth_class,
            'score': trend_info['score'],
            'label': trend_info['label'],
            'description': trend_info['description'],
            'ranking': cls._get_ranking(trend_type),
            'timeline': cls._get_timeline(trend_type, growth),
            'opportunity_level': cls._get_opportunity_level(trend_type)
        }
    
    @staticmethod
    def _get_trend_type(volume_class: str, growth_class: str) -> str:
        """Определи тип тренда по volume_class + growth_class"""
        
        # Early trends: Low volume + High/Explosive growth
        if volume_class == 'low' and growth_class in ['high_growth', 'explosive_growth']:
            return 'early_trend'
        
        # Rocket trends: Low/Medium volume + Explosive growth
        if volume_class in ['low', 'medium'] and growth_class == 'explosive_growth':
            return 'rocket_trend'
        
        # Hyper trends: High volume + High/Explosive growth
        if volume_class in ['high', 'very_high'] and growth_class in ['high_growth', 'explosive_growth']:
            return 'hyper_trend'
        
        # Emerging trends: Medium volume + Medium/High growth
        if volume_class == 'medium' and growth_class in ['medium_growth', 'high_growth']:
            return 'emerging_trend'
        
        # Established trends: High volume + Low/No growth
        if volume_class in ['high', 'very_high'] and growth_class in ['stable', 'low_growth']:
            return 'established_trend'
        
        # Niche trends: Low/Medium volume + Low growth
        if volume_class in ['low', 'medium'] and growth_class in ['low_growth', 'stable']:
            return 'niche_trend'
        
        # Declining trends: Negative growth
        if growth_class == 'declining':
            return 'declining_trend'
        
        # Default: Stable
        return 'stable_trend'
    
    @staticmethod
    def _get_ranking(trend_type: str) -> str:
        """Получи ранк для инвестирования"""
        rankings = {
            'early_trend': '🏆 MUST WATCH - Highest ROI potential',
            'rocket_trend': '⭐⭐⭐ CRITICAL - Explosive growth',
            'hyper_trend': '⭐⭐ HOT - Mainstream adoption',
            'emerging_trend': '⭐ GROWING - Building momentum',
            'established_trend': '✅ SAFE - Stable, low risk',
            'niche_trend': '🎯 NICHE - Specialized audience',
            'declining_trend': '❌ AVOID - Losing momentum',
            'stable_trend': '➡️ NEUTRAL - No momentum'
        }
        return rankings.get(trend_type, 'UNKNOWN')
    
    @staticmethod
    def _get_timeline(trend_type: str, growth: float) -> str:
        """Предскажи timeline для тренда"""
        if trend_type in ['early_trend', 'rocket_trend']:
            if growth > 5000:
                return '⚡ NOW (1-3 months)'
            elif growth > 1000:
                return '📅 SOON (3-6 months)'
            else:
                return '🗓️ COMING (6-12 months)'
        elif trend_type in ['hyper_trend']:
            return '✅ IN PROGRESS (current)'
        elif trend_type in ['emerging_trend']:
            return '📊 6-12 months out'
        else:
            return '➡️ Established/declining'
    
    @staticmethod
    def _get_opportunity_level(trend_type: str) -> str:
        """Уровень возможностей"""
        levels = {
            'early_trend': 'EXTREME',
            'rocket_trend': 'VERY HIGH',
            'hyper_trend': 'HIGH',
            'emerging_trend': 'MEDIUM',
            'established_trend': 'LOW',
            'niche_trend': 'MEDIUM (specialized)',
            'declining_trend': 'NEGATIVE',
            'stable_trend': 'NEUTRAL'
        }
        return levels.get(trend_type, 'UNKNOWN')


class ExplodingTopicsScraper:
    """
    Парсер для explodingtopics.com.
    
    Использует: https://github.com/PolSust/exploding-topics-scraper
    
    Или альтернатива - скрейпим через Selenium если нужна свежесть.
    """
    
    def __init__(self):
        self.base_url = "https://explodingtopics.com"
        self.session = requests.Session()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def get_latest_trends(self, category: Optional[str] = None) -> List[Trend]:
        """
        Получи последние тренды.
        
        Args:
            category: Опционально фильтр по категории
                     (e.g., 'technology', 'business', 'health')
        
        Returns:
            Список трендов с метриками
        """
        
        try:
            # Вариант 1: Используй NPM пакет exploding-topics-scraper
            # (если у тебя есть Node.js)
            trends = self._scrape_with_nodejs(category)
            
            # Вариант 2: Если Node.js не доступен, используй Selenium
            if not trends:
                trends = self._scrape_with_selenium(category)
            
            return trends
        
        except Exception as e:
            logger.error(f"Error scraping Exploding Topics: {e}")
            return []
    
    def _scrape_with_nodejs(self, category: Optional[str] = None) -> List[Trend]:
        """
        Используй Node.js пакет для парсинга.
        
        Setup:
            npm install exploding-topics-scraper
        
        Usage в Python:
            import subprocess
            result = subprocess.run(['node', 'scraper.js'], capture_output=True)
        """
        
        try:
            import subprocess
            import json
            
            # Создай временный скрипт
            script = """
const scraper = require('exploding-topics-scraper');

scraper.getTrends().then(trends => {
    console.log(JSON.stringify(trends, null, 2));
}).catch(error => {
    console.error('Error:', error);
});
"""
            
            with open('/tmp/scraper.js', 'w') as f:
                f.write(script)
            
            result = subprocess.run(
                ['node', '/tmp/scraper.js'],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return self._parse_trends_response(data, category)
            
            return []
        
        except Exception as e:
            logger.warning(f"Node.js scraping failed: {e}")
            return []
    
    def _scrape_with_selenium(self, category: Optional[str] = None) -> List[Trend]:
        """
        Используй Selenium для scraping-a.
        
        Setup:
            pip install selenium
            # Скачай chromedriver: https://chromedriver.chromium.org/
        """
        
        try:
            from selenium import webdriver
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support.ui import WebDriverWait
            from selenium.webdriver.support import expected_conditions as EC
            
            driver = webdriver.Chrome()
            driver.get(f"{self.base_url}/")
            
            # Жди загрузки трендов
            wait = WebDriverWait(driver, 10)
            trend_elements = wait.until(
                EC.presence_of_all_elements_located((By.CLASS_NAME, "trend-item"))
            )
            
            trends = []
            for element in trend_elements[:20]:  # Top 20 trends
                try:
                    name = element.find_element(By.CLASS_NAME, "trend-name").text
                    volume_text = element.find_element(By.CLASS_NAME, "volume").text
                    growth_text = element.find_element(By.CLASS_NAME, "growth").text
                    
                    # Parse: "1.6K" -> 1600
                    volume = self._parse_volume(volume_text)
                    # Parse: "+6800%" -> 6800
                    growth = self._parse_growth(growth_text)
                    
                    trend = Trend(
                        name=name,
                        category=category or "general",
                        metrics=TrendMetrics(volume=volume, growth=growth),
                        url=element.find_element(By.TAG_NAME, "a").get_attribute("href")
                    )
                    
                    trends.append(trend)
                
                except Exception as e:
                    logger.warning(f"Error parsing trend element: {e}")
                    continue
            
            driver.quit()
            return trends
        
        except Exception as e:
            logger.error(f"Selenium scraping failed: {e}")
            return []
    
    def _parse_trends_response(self, data: List[Dict], category: Optional[str]) -> List[Trend]:
        """Парсим ответ от scraper'а"""
        trends = []
        
        for item in data:
            try:
                volume = item.get('volume', 0)
                growth = item.get('growth', 0)
                
                # Если volume строка (e.g., "1.6K") - парсим
                if isinstance(volume, str):
                    volume = self._parse_volume(volume)
                
                # Если growth строка (e.g., "+6800%") - парсим
                if isinstance(growth, str):
                    growth = self._parse_growth(growth)
                
                trend = Trend(
                    name=item.get('name', ''),
                    category=category or item.get('category', 'general'),
                    metrics=TrendMetrics(volume=volume, growth=growth),
                    description=item.get('description'),
                    url=item.get('url')
                )
                
                trends.append(trend)
            
            except Exception as e:
                logger.warning(f"Error parsing trend: {e}")
                continue
        
        return trends
    
    @staticmethod
    def _parse_volume(volume_str: str) -> int:
        """
        Parse volume string.
        
        Examples:
        "1.6K" -> 1600
        "45K" -> 45000
        "1.2M" -> 1200000
        """
        try:
            volume_str = str(volume_str).strip().upper()
            
            if 'K' in volume_str:
                num = float(volume_str.replace('K', '')) * 1_000
            elif 'M' in volume_str:
                num = float(volume_str.replace('M', '')) * 1_000_000
            elif 'B' in volume_str:
                num = float(volume_str.replace('B', '')) * 1_000_000_000
            else:
                num = float(volume_str)
            
            return int(num)
        except:
            return 0
    
    @staticmethod
    def _parse_growth(growth_str: str) -> float:
        """
        Parse growth percentage.
        
        Examples:
        "+6800%" -> 6800
        "-15%" -> -15
        "0%" -> 0
        """
        try:
            growth_str = str(growth_str).strip()
            # Remove % sign
            growth_str = growth_str.replace('%', '')
            return float(growth_str)
        except:
            return 0


class TrendAnalyzer:
    """
    Анализ трендов с использованием TrendScorer.
    """
    
    def __init__(self):
        self.scorer = TrendScorer()
    
    def analyze_trends(self, trends: List[Trend]) -> List[Dict]:
        """
        Анализируй список трендов.
        
        Returns:
            List of trends with classification, scores, and insights
        """
        
        analyzed = []
        
        for trend in trends:
            classification = self.scorer.classify_trend(trend)
            
            analyzed_trend = {
                'name': trend.name,
                'category': trend.category,
                'metrics': {
                    'volume': trend.metrics.volume,
                    'growth': trend.metrics.growth,
                    'growth_direction': trend.metrics.growth_direction
                },
                'classification': classification,
                'fetched_at': trend.fetched_at
            }
            
            analyzed.append(analyzed_trend)
        
        # Отсортируй по score (высокие вверху)
        analyzed.sort(
            key=lambda x: x['classification']['score'],
            reverse=True
        )
        
        return analyzed
    
    def get_top_early_trends(self, trends: List[Dict], limit: int = 10) -> List[Dict]:
        """Получи топ early trends (самые ценные)"""
        early_trends = [
            t for t in trends
            if t['classification']['trend_type'] in ['early_trend', 'rocket_trend']
        ]
        return sorted(
            early_trends,
            key=lambda x: x['classification']['score'],
            reverse=True
        )[:limit]
    
    def get_hypertrends(self, trends: List[Dict], limit: int = 5) -> List[Dict]:
        """Получи hyper trends (очень популярные прямо сейчас)"""
        hyper = [
            t for t in trends
            if t['classification']['trend_type'] == 'hyper_trend'
        ]
        return sorted(
            hyper,
            key=lambda x: x['metrics']['volume'],
            reverse=True
        )[:limit]


# ==============================================================================
# ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ
# ==============================================================================

if __name__ == '__main__':
    import json
    
    # Setup логирования
    logging.basicConfig(level=logging.INFO)
    
    print("🚀 Exploding Topics Trend Analyzer\n")
    
    # 1. Получи тренды
    print("📊 Fetching trends from explodingtopics.com...")
    scraper = ExplodingTopicsScraper()
    trends = scraper.get_latest_trends(category='technology')
    
    if not trends:
        print("⚠️ No trends fetched. Trying alternative method...")
        # Симуляция для демонстрации
        trends = [
            Trend(
                name='AI Agents',
                category='technology',
                metrics=TrendMetrics(volume=8500, growth=6800)
            ),
            Trend(
                name='Quantum Computing',
                category='technology',
                metrics=TrendMetrics(volume=45000, growth=250)
            ),
            Trend(
                name='Neural Networks',
                category='technology',
                metrics=TrendMetrics(volume=120000, growth=8)
            ),
            Trend(
                name='Web3 Gaming',
                category='technology',
                metrics=TrendMetrics(volume=3200, growth=1500)
            ),
            Trend(
                name='Blockchain',
                category='technology',
                metrics=TrendMetrics(volume=250000, growth=-5)
            ),
        ]
    
    # 2. Анализируй
    print("🔍 Analyzing trends...\n")
    analyzer = TrendAnalyzer()
    analyzed = analyzer.analyze_trends(trends)
    
    # 3. Выведи результаты
    print("=" * 100)
    print("🎯 TREND ANALYSIS RESULTS")
    print("=" * 100)
    
    for trend in analyzed:
        classification = trend['classification']
        metrics = trend['metrics']
        
        print(f"\n{classification['label']} {trend['name'].upper()}")
        print(f"├─ Volume: {metrics['volume']:,} searches/month")
        print(f"├─ Growth: {metrics['growth']:+.1f}% ({metrics['growth_direction']})")
        print(f"├─ Score: {classification['score']}/100")
        print(f"├─ Type: {classification['trend_type']}")
        print(f"├─ Ranking: {classification['ranking']}")
        print(f"├─ Timeline: {classification['timeline']}")
        print(f"└─ Opportunity: {classification['opportunity_level']}")
        print(f"   📝 {classification['description']}")
    
    # 4. Top Early Trends
    print("\n" + "=" * 100)
    print("🚀 TOP EARLY TRENDS (MUST WATCH)")
    print("=" * 100)
    
    early_trends = analyzer.get_top_early_trends(analyzed, limit=5)
    for i, trend in enumerate(early_trends, 1):
        print(f"\n{i}. {trend['name']} {trend['classification']['label']}")
        print(f"   Volume: {trend['metrics']['volume']:,} | Growth: {trend['metrics']['growth']:+.1f}%")
        print(f"   Timeline: {trend['classification']['timeline']}")
        print(f"   Opportunity: {trend['classification']['opportunity_level']}")
    
    # 5. Hyper Trends
    print("\n" + "=" * 100)
    print("🔥 HYPER TRENDS (CURRENT)")
    print("=" * 100)
    
    hyper_trends = analyzer.get_hypertrends(analyzed, limit=3)
    for i, trend in enumerate(hyper_trends, 1):
        print(f"\n{i}. {trend['name']} (🎯 {trend['metrics']['volume']:,} searches/month)")
        print(f"   Growing at: {trend['metrics']['growth']:+.1f}%")
    
    # 6. Export as JSON
    print("\n" + "=" * 100)
    print("💾 Exporting to JSON...")
    with open('/tmp/trends_analysis.json', 'w') as f:
        json.dump(analyzed, f, indent=2, default=str)
    print("✅ Saved to /tmp/trends_analysis.json")
